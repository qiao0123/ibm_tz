<!-- 底部 -->
 	<div class = "footer">
		<div class = "layui-container">
			<div class = "layui-row">
				<div class = "layui-col-lg12">
				Copyright © 2017-2020
				</div>
			</div>
		</div>
	</div>
	<!-- 底部END -->
	
	<!--遍历目录END-->
	<script type="text/javascript" src = "./static/jquery.min.js"></script>
	<script src = 'https://libs.xiaoz.top/assets/zdir.js'></script>
	<script type="text/javascript" src="./static/layui/layui.js"></script>
	<script type="text/javascript" src="./static/embed.js?v=<?php echo $version; ?>"></script>
	<script type="text/javascript" src="./static/clipBoard.min.js"></script>
</body>
</html>